# -*- coding: utf-8 -*-
"""
Локальная админка сайта «Особый маршрут».

Запуск:  python server.py
Затем открыть http://127.0.0.1:8800/admin/

Сервер отдаёт сам сайт и панель управления, сохраняет контент
в assets/data/content.js и складывает загруженные файлы в media/.
Ничего устанавливать не нужно — только стандартная библиотека Python.
"""

import http.server
import socketserver
import json
import os
import re
import shutil
import sys
import unicodedata
import webbrowser
from datetime import datetime
from urllib.parse import urlparse, parse_qs, unquote

ROOT = os.path.dirname(os.path.abspath(__file__))
CONTENT_JS = os.path.join(ROOT, 'assets', 'data', 'content.js')
MEDIA_DIR = os.path.join(ROOT, 'media')
BACKUP_DIR = os.path.join(ROOT, '.backups')

HOST = '127.0.0.1'
FIRST_PORT = 8800
MAX_UPLOAD = 400 * 1024 * 1024          # 400 МБ на файл
KEEP_BACKUPS = 30

HEADER = """/* =========================================================
   Весь контент сайта. Этот файл переписывает админка —
   вручную править его не нужно, но можно.
   Формат: обычный JS-файл, чтобы сайт открывался и без сервера.
   ========================================================= */
window.SITE_CONTENT = """

ALLOWED_EXT = {
    'image': {'.jpg', '.jpeg', '.png', '.gif', '.webp', '.avif', '.svg'},
    'video': {'.mp4', '.webm', '.ogv', '.mov', '.m4v'},
    'pdf': {'.pdf'},
}

TRANSLIT = {
    'а': 'a', 'б': 'b', 'в': 'v', 'г': 'g', 'д': 'd', 'е': 'e', 'ё': 'e', 'ж': 'zh',
    'з': 'z', 'и': 'i', 'й': 'y', 'к': 'k', 'л': 'l', 'м': 'm', 'н': 'n', 'о': 'o',
    'п': 'p', 'р': 'r', 'с': 's', 'т': 't', 'у': 'u', 'ф': 'f', 'х': 'h', 'ц': 'c',
    'ч': 'ch', 'ш': 'sh', 'щ': 'sch', 'ъ': '', 'ы': 'y', 'ь': '', 'э': 'e',
    'ю': 'yu', 'я': 'ya',
}


# ----------------------------- утилиты -----------------------------

def slugify(name):
    """Имя файла в безопасный латинский вид, чтобы ссылки работали на любом хостинге."""
    base, ext = os.path.splitext(name)
    base = unicodedata.normalize('NFKC', base).lower()
    out = []
    for ch in base:
        if ch in TRANSLIT:
            out.append(TRANSLIT[ch])
        elif ch.isalnum() and ch.isascii():
            out.append(ch)
        else:
            out.append('-')
    base = re.sub(r'-{2,}', '-', ''.join(out)).strip('-') or 'file'
    return base[:60], ext.lower()


def read_content():
    with open(CONTENT_JS, 'r', encoding='utf-8') as f:
        text = f.read()
    start = text.index('{', text.index('SITE_CONTENT'))
    end = text.rindex('}')
    return json.loads(text[start:end + 1])


def write_content(data):
    os.makedirs(BACKUP_DIR, exist_ok=True)
    if os.path.exists(CONTENT_JS):
        stamp = datetime.now().strftime('%Y%m%d-%H%M%S')
        shutil.copy2(CONTENT_JS, os.path.join(BACKUP_DIR, 'content-%s.js' % stamp))
        backups = sorted(os.listdir(BACKUP_DIR))
        for old in backups[:-KEEP_BACKUPS]:
            try:
                os.remove(os.path.join(BACKUP_DIR, old))
            except OSError:
                pass

    os.makedirs(os.path.dirname(CONTENT_JS), exist_ok=True)
    body = HEADER + json.dumps(data, ensure_ascii=False, indent=2) + ';\n'
    tmp = CONTENT_JS + '.tmp'
    with open(tmp, 'w', encoding='utf-8', newline='\n') as f:
        f.write(body)
    os.replace(tmp, CONTENT_JS)


def media_path(rel):
    """Безопасно превращает 'media/x.jpg' в абсолютный путь внутри media/."""
    rel = unquote(str(rel or '')).replace('\\', '/')
    if not rel.startswith('media/'):
        return None
    full = os.path.abspath(os.path.join(ROOT, rel))
    if os.path.commonpath([full, MEDIA_DIR]) != MEDIA_DIR:
        return None
    return full


# ----------------------------- сервер -----------------------------

class Handler(http.server.SimpleHTTPRequestHandler):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=ROOT, **kwargs)

    def log_message(self, fmt, *args):
        if '/api/' in (args[0] if args else ''):
            sys.stdout.write('  %s\n' % (fmt % args))

    def end_headers(self):
        # Админка должна видеть свежие данные, а не кэш браузера
        self.send_header('Cache-Control', 'no-store')
        super().end_headers()

    # ------------------------- ответы -------------------------

    def send_json(self, obj, status=200):
        payload = json.dumps(obj, ensure_ascii=False).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    def fail(self, message, status=400):
        self.send_json({'ok': False, 'error': message}, status)

    def read_body(self, limit=MAX_UPLOAD):
        length = int(self.headers.get('Content-Length') or 0)
        if length <= 0:
            return b''
        if length > limit:
            raise ValueError('Файл слишком большой (больше %d МБ)' % (limit // 1024 // 1024))
        return self.rfile.read(length)

    # --------------------------- GET ---------------------------

    def do_GET(self):
        path = urlparse(self.path).path

        if path == '/api/content':
            try:
                return self.send_json({'ok': True, 'content': read_content()})
            except Exception as e:
                return self.fail('Не удалось прочитать content.js: %s' % e, 500)

        if path == '/api/media':
            os.makedirs(MEDIA_DIR, exist_ok=True)
            files = []
            for name in sorted(os.listdir(MEDIA_DIR)):
                full = os.path.join(MEDIA_DIR, name)
                if os.path.isfile(full):
                    files.append({'file': 'media/' + name, 'size': os.path.getsize(full)})
            return self.send_json({'ok': True, 'files': files})

        if path == '/':
            self.send_response(302)
            self.send_header('Location', '/admin/')
            self.end_headers()
            return

        return super().do_GET()

    # --------------------------- POST ---------------------------

    def do_POST(self):
        parsed = urlparse(self.path)
        path, query = parsed.path, parse_qs(parsed.query)

        try:
            if path == '/api/content':
                data = json.loads(self.read_body(20 * 1024 * 1024).decode('utf-8'))
                if not isinstance(data, dict):
                    return self.fail('Ожидался объект с контентом')
                write_content(data)
                return self.send_json({'ok': True, 'savedAt': datetime.now().strftime('%H:%M:%S')})

            if path == '/api/upload':
                kind = (query.get('kind') or ['image'])[0]
                raw_name = unquote(self.headers.get('X-Filename') or 'file')
                base, ext = slugify(os.path.basename(raw_name))
                allowed = ALLOWED_EXT.get(kind, set())
                if ext not in allowed:
                    return self.fail('Такой формат сюда загрузить нельзя. Допустимо: %s'
                                     % ', '.join(sorted(allowed)))

                body = self.read_body()
                if not body:
                    return self.fail('Пустой файл')

                os.makedirs(MEDIA_DIR, exist_ok=True)
                name = base + ext
                if os.path.exists(os.path.join(MEDIA_DIR, name)):
                    name = '%s-%s%s' % (base, datetime.now().strftime('%H%M%S'), ext)
                with open(os.path.join(MEDIA_DIR, name), 'wb') as f:
                    f.write(body)
                return self.send_json({'ok': True, 'file': 'media/' + name, 'size': len(body)})

            if path == '/api/delete-media':
                data = json.loads(self.read_body(1024 * 64).decode('utf-8'))
                full = media_path(data.get('file'))
                if not full:
                    return self.fail('Можно удалять только файлы из папки media')
                if os.path.exists(full):
                    os.remove(full)
                return self.send_json({'ok': True})

            return self.fail('Неизвестный адрес: %s' % path, 404)

        except ValueError as e:
            return self.fail(str(e), 413)
        except Exception as e:
            return self.fail('Ошибка сервера: %s' % e, 500)


def main():
    for ext, mime in (('.js', 'application/javascript'), ('.mp4', 'video/mp4'),
                      ('.webm', 'video/webm'), ('.mov', 'video/quicktime'),
                      ('.m4v', 'video/mp4'), ('.webp', 'image/webp'),
                      ('.avif', 'image/avif'), ('.json', 'application/json')):
        Handler.extensions_map[ext] = mime

    os.makedirs(MEDIA_DIR, exist_ok=True)

    if not os.path.exists(CONTENT_JS):
        print('Не найден файл assets/data/content.js — запустите сервер из папки сайта.')
        return 1

    socketserver.TCPServer.allow_reuse_address = True
    for port in range(FIRST_PORT, FIRST_PORT + 20):
        try:
            httpd = socketserver.ThreadingTCPServer((HOST, port), Handler)
        except OSError:
            continue

        url = 'http://%s:%d/admin/' % (HOST, port)
        print('')
        print('  Админка сайта «Особый маршрут»')
        print('  ------------------------------------------')
        print('  Панель управления: %s' % url)
        print('  Сайт:              http://%s:%d/index.html' % (HOST, port))
        print('')
        print('  Чтобы остановить — закройте это окно или нажмите Ctrl+C.')
        print('')
        try:
            webbrowser.open(url)
        except Exception:
            pass
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print('\n  Остановлено.')
        finally:
            httpd.server_close()
        return 0

    print('Не удалось занять ни один порт в диапазоне %d-%d.' % (FIRST_PORT, FIRST_PORT + 19))
    return 1


if __name__ == '__main__':
    sys.exit(main())
