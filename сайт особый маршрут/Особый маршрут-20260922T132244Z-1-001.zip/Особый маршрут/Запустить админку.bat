@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Админка сайта «Особый маршрут»

where py >nul 2>nul
if %errorlevel%==0 (
    py -3 server.py
    goto end
)

where python >nul 2>nul
if %errorlevel%==0 (
    python server.py
    goto end
)

echo.
echo   Не найден Python.
echo   Скачайте его с https://www.python.org/downloads/ и при установке
echo   поставьте галочку "Add Python to PATH", затем запустите файл снова.
echo.
pause

:end
